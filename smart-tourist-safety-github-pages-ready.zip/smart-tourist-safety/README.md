# Smart Tourist Safety — Frontend Prototype

A colorful, responsive React demonstration for the college project **“Smart Tourist Safety Monitoring and Incident Response System Using AI, Geo-Fencing, and Blockchain-Based Digital ID.”**

## 1. Requirements

- Node.js 18+ (Node.js 20 LTS recommended)
- npm
- Internet connection for OpenStreetMap tiles and Google Fonts (the app layout itself runs locally)

## 2. Run locally

Open a terminal inside this project folder:

```bash
npm install
npm run dev
```

Vite prints a local URL, usually `http://localhost:5173`. Open it in Chrome or Edge.

Build check:

```bash
npm run build
npm run preview
```

## 3. Demo account behaviour

- **Tourist:** On Login, enter any valid email and a password with at least 6 characters.
- **Admin:** Use an email beginning with `admin`, for example `admin@example.com`, and any password with at least 6 characters.
- Registration checks required fields, email, phone format, password length, matching passwords, and location-consent checkbox.
- The frontend does not save or send the password. Demo profile, monitoring toggle, and incident records may be kept in this browser's `localStorage`; use fictional data only.
- To clear local demo data, open browser DevTools → Application/Storage → Local Storage → clear the site entries, or use the browser's site data controls.

## 4. Features that work in this prototype

- Responsive homepage, navigation, footer, feature overview, and contact form preview.
- Registration and login form validation (demo identity only).
- Tourist dashboard with profile, location status, activity, and incident summary.
- Browser geolocation request after user action, subject to browser permission and secure-context requirements. `localhost` is generally treated as secure for local testing.
- Leaflet map using OpenStreetMap tiles; map initially shows a clearly labelled Chennai demo point.
- Sample geo-fence circle, a button to simulate entering the zone, and an explanatory rule-based risk event.
- Emergency alert confirmation modal, local incident creation, timestamps, IDs, and status.
- Demo Digital ID with honest “not connected / unverified” labels.
- Admin demo view with searchable/filterable sample tourists and incident status updates.
- Contact form success feedback (no email is sent).

## 5. Demo-only / not connected

- **Authentication:** not secure real authentication; any valid demo email/password passes. No password is stored.
- **GPS:** only reads the browser's location when requested. No background tracking.
- **Geo-fencing:** one sample boundary, not an official restricted zone or danger database.
- **Risk analysis:** transparent rules only; no trained AI model.
- **Emergency alerts:** creates an in-browser incident only; does not contact police, emergency services, or family.
- **Digital ID / blockchain:** sample display only; no identity authority, cryptographic verification, or blockchain transaction.
- **Admin data and chart:** illustrative local sample records, not live analytics.
- **Contact:** preview only; no email or server request.

## 6. Frontend structure

```text
smart-tourist-safety/
├── index.html
├── package.json
├── README.md
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   └── styles.css
└── backend/
    └── README.md
```

`App.jsx` contains the demo views and local state; `styles.css` contains the responsive design system. For a larger production app, split views into `pages/`, shared elements into `components/`, and API clients into `services/`.

## 7. Connect a Flask backend later

1. Build API endpoints based on `backend/README.md`.
2. Keep secrets and database credentials in backend environment variables, never in React code.
3. Add a `.env` file for frontend public configuration only, for example `VITE_API_BASE_URL=http://localhost:5000/api`. Anything prefixed `VITE_` is public in the browser bundle.
4. Replace demo login and localStorage updates with `fetch()` calls to the API. Use secure HttpOnly cookies for sessions, appropriate CORS allow-lists, CSRF protections where applicable, rate limiting, and server-side authorization.
5. Store passwords only as strong salted hashes (Argon2id or bcrypt); never log credentials.
6. Add database migrations and validation. Do not save continuous location history unless it is necessary, consented to, access-controlled, and covered by a retention policy.

## 8. Maps

Leaflet and OpenStreetMap tiles are already configured in `src/App.jsx`. Internet is needed for tile loading. Follow the OpenStreetMap tile usage policy, preserve attribution, and consider a suitable tile provider if traffic grows. Geolocation typically works on `localhost` or HTTPS, and the user must grant permission.

## 9. AI / ML integration

Create a protected Python endpoint such as `POST /api/risk/analyze` that accepts only the minimum necessary location/event data and returns a structured response such as `{ "level": "warning", "reason": "Entered configured boundary", "model_version": "..." }`. Validate input, document model limitations, avoid presenting probabilistic outputs as certainty, and retain the current “Unknown” state when there is insufficient evidence. The frontend currently uses explicit demonstration rules, not a real model.

## 10. Blockchain / Digital ID integration

Do not store raw passport or sensitive personal data on-chain. A production design should use minimal claims, off-chain encrypted records, revocable identifiers, and a reviewed verification contract or credential standard. Keep signing keys in a backend-managed secret store or hardware security module. Return a transaction reference only after the backend verifies a real transaction.

## 11. Notifications / emergency workflow

A real notification service needs a backend, verified recipient consent, abuse prevention, delivery-status handling, and audit logs. Clearly distinguish “created”, “sent”, “delivered”, and “resolved”; do not mark a message sent until the provider confirms it. Keep local emergency numbers and official procedures available independently of the app.

## 12. Important privacy note

This is a college project prototype, not an emergency-response service. Use fictional test data only. Do not enter real passport numbers or other sensitive information.


## Publish on GitHub Pages

This package is configured to deploy with GitHub Actions.

1. Create a **public** GitHub repository named exactly `smart-tourist-safety`.
2. Upload the **contents** of this project folder to the repository root (do not upload the outer ZIP itself).
3. Make sure the default branch is named `main`.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **GitHub Actions**.
6. Open the **Actions** tab and wait for the “Deploy website to GitHub Pages” workflow to finish successfully.
7. Your site should appear at `https://YOUR-GITHUB-USERNAME.github.io/smart-tourist-safety/`.

The Vite base path is set for a repository named `smart-tourist-safety`. If you use a different repository name, update `base` in `vite.config.js` to `'/YOUR-REPOSITORY-NAME/'` before uploading.

This is a frontend demo. Login, alerts, geofencing and digital-ID actions are demonstrations and are not connected to a production backend or emergency services.

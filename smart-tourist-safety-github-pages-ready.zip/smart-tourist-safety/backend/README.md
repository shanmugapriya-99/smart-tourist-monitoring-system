# Optional Python backend integration

The current frontend runs independently. This folder is a suggested place for a Flask API later; no backend is required to run the prototype.

Suggested endpoints:
- `POST /api/auth/register` — validate and hash passwords with Argon2id or bcrypt; never log passwords.
- `POST /api/auth/login` — issue secure, HttpOnly, SameSite cookies; avoid storing long-lived tokens in localStorage.
- `GET /api/tourists/me` — authenticated profile.
- `POST /api/location-events` — consented, purpose-limited location event.
- `GET /api/risk/events` — explainable risk event records.
- `POST /api/incidents` and `PATCH /api/incidents/:id` — incident workflow.
- `GET /api/digital-id/:id` — minimal identity claims and verification status.

Before production, add HTTPS, CSRF protection where applicable, rate limiting, schema validation, authorization checks on every endpoint, audit logging, data-retention controls, and security testing. Do not expose database credentials, AI service keys, or blockchain private keys in the browser.
